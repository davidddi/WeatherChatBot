var request = require('request')
var tempUnitsConv = require('temp-units-conv')
const { addContext } = require('./../api/context')

const getWeatherForcast = function (req, res) {
  var speech = 'Je ne peux pas te donner la météo'
  var location = req.body.result.parameters['geo-city']

  if (location !== undefined && location !== '') {
    callWeatherForcastAPI(location).then(function (weather) {
      if (weather.result.list.length > 0) {
        var firstElement = weather.result.list[0].main.temp_max

        var maxTemperature = Math.round(tempUnitsConv.k2c(firstElement))
        speech = 'Il fera ' + maxTemperature + ' degrés à ' + location
      }
      else {
        speech = "Aucune prévision n'a été trouvée"
      }
      res.send({
        'speech': speech,
        'displayText': speech,
        'data': {'slack': {'text': speech}},
        'source': 'weather'
      })
    })
  } else {
    addContext(req.body.sessionId, 'weather-missing-location', 1, null).then(function (result) {
      speech = 'Indique moi où tu veux connaitre les prévisions météo'
      res.send({
        'speech': speech,
        'displayText': speech,
        'data': {'slack': {'text': speech}},
        'source': 'weather'
      })
    })
  }
}

const callWeatherForcastAPI = function (location) {
  return new Promise((resolve, reject) => {
    var url = 'http://api.openweathermap.org/data/2.5/forecast?q=' + location + '&appid=' + process.env.WEATHER_KEY

    request.get({
      url: url,
      json: true
    }, function (error, result, body) {
      if (error) {
        reject(error)
      }

      resolve({
        result: body
      })
    })
  })
}


module.exports = {
  getWeatherForcast
}