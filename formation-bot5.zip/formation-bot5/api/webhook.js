const { getInfo } = require("./../services/myApi")

const { getWeather } = require("./../services/weather")
const { getOcto } = require("./../services/askbob")


const postAction = function (req, res) {
    var action = req.body.result.action

    console.log(action)

    switch (action) {
        case "accountMove":

            var speech = "Vous pouvez voir les opérations passées sur votre banque en ligne";
            res.json({
                "speech": speech,
                "displayText": speech,
                "data": {"slack": {"text": speech}},
                "source": "maBanque"
            })
            break
        case "askbob":
            getOcto(req, res)
            break
        case "weather":
            getWeather(req, res)
            break
        // case action weatherForcast
       // case "weatherForcast":
       //     getWeatherForcast(req, res)
       //     break
        case "myAction":
            getInfo(req, res)
        default:
            var message = "nothing to execute for this action : " + action;
            console.log(message);
            res.json({message: action});
    }
}

module.exports = {
    postAction
}