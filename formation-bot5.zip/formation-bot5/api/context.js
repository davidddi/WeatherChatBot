const request = require("request")

const addContext = function(idSession, name, lifespan, parameters) {
    return new Promise((resolve, reject) => {

        var url = "https://api.api.ai/v1/contexts?sessionId="+idSession

        request.post({
            url: url,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + process.env.API_AI_ACCESS_TOKEN
            },
            body: [
                {
                    "name": name,
                    "lifespan": lifespan,
                    "parameters": parameters
                }]
        }, function (error, result, body) {
            if (error) {
                reject(error);
            }
            console.log("success")
            console.log(body)
            resolve({
                result: body
            })
        })
    })
}

const deleteContext = function(idSession, name) {
    return new Promise((resolve, reject) => {

            var url = "https://api.api.ai/v1/contexts/"+ name +"?sessionId="+idSession

            request.delete({
            url: url,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + process.env.API_AI_ACCESS_TOKEN
            }
        }, function (error, result, body) {
            if (error) {
                reject(error);
            }
            console.log("success")
            console.log(body)
            resolve({
                result: body
            })
        })
    })
}

module.exports = {
    addContext,
    deleteContext
}