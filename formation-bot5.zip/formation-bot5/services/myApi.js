const request = require("request")

const getInfo = function (req, res) {

    var url = "http://[API URL]/[resource]"

        request.get({
            url: url,
            json: true
        }, function (error, result) {
            if (error) {
                reject(error);
            }

            resolve({
                    "data": {"slack": slackData},
                    "source": "askBob"
                });
        });

}

module.exports = {
    getInfo
}