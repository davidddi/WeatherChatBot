var request = require('request')
var tempUnitsConv = require('temp-units-conv')
const { addContext } = require('./../api/context')

const getWeather = function (req, res) {
  var speech = 'Je ne peux pas te donner la météo'
  var location = req.body.result.parameters['geo-city']

  if (location !== undefined && location !== '') {
    callWeatherAPI(location).then(function (weather) {
      var maxTemperature = tempUnitsConv.k2c(weather.result.main.temp_max)
      speech = 'La température à ' + location + ' est de ' + maxTemperature + " degrés pour aujourd'hui"
      res.send({
        'speech': speech,
        'displayText': speech,
        'data': {'slack': {'text': speech}},
        'source': 'weather'
      })
    })
  } else {
    addContext(req.body.sessionId, 'weather-missing-location', 1, null).then(function (result) {
      speech = 'Indique moi où tu veux connaitre la météo'
      res.send({
        'speech': speech,
        'displayText': speech,
        'data': {'slack': {'text': speech}},
        'source': 'weather'
      })
    })
  }
}

const callWeatherAPI = function (location) {
  return new Promise((resolve, reject) => {
    var url = 'http://api.openweathermap.org/data/2.5/weather?q=' + location + '&appid=' + process.env.WEATHER_KEY

    request.get({
      url: url,
      json: true
    }, function (error, result, body) {
      if (error) {
        reject(error)
      }

      resolve({
        result: body
      })
    })
  })
}

const getWeatherForcast = function (req, res) {
  // 1. extract geo-city parameter
  // 2. if check geo-city not null then callWeatherForcastAPI
  // 3. else return where do you want the weather forcast
}

const callWeatherForcastAPI = function (location) {
  return new Promise((resolve, reject) => {
      // url to be defined
    var url = ''
      // request.get
    resolve({error: 'not implemented'})
  })
}

module.exports = {
  getWeather,
  getWeatherForcast
}
