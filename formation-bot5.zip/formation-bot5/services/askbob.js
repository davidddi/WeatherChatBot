/**
 * Created by Thibaut Cantt on 08/06/2017.
 */
const request = require("request")

const getOcto = function (req, res) {
    var trigram = req.body.result.parameters["OctoMember"]
    if (trigram == undefined || trigram == '') {
        res.send({
            "speech": "no trigram found in the posted json",
            "displayText": "no trigram found in the posted json",
            "source": "askBob"
        });
    }
    else {
        fetchOcto(trigram).then(function(octo) {
            res.send(octo)
        })
    }
}

const fetchOcto = function (trigram) {
    return new Promise((resolve, reject) => {

        var url = "http://askbob.octo.com/api/v1/" + process.env.ASKBOB_KEY + "/people/" + trigram + ".json"

            console.log(url)
        request.get({
            url: url,
            json: true
        }, function (error, result) {
            if (error) {
                return reject(error);
            }
            if (result.body.items == undefined) {
                var speech = "Aucun Octo n'est connu pour ce trigramme";
                resolve(null, {
                    "speech": speech,
                    "displayText": speech,
                    "data": {"slack": {"text": speech}},
                    "source": "askBob"
                });
            }
            var item = result.body.items[0];
            var imageUrl = item.big_photo;
            var url = "http://askbob.octo.com/users/" + trigram;
            var slackData = {
                "attachments": [
                    {
                        "fallback": "Infos Askbob",
                        "color": "#36a64f",
                        "pretext": "Voici ce que nous savons de " + trigram,
                        "author_name": "Askbob",
                        "author_link": "http://askbob.octo.com/",
                        "author_icon": "http://askbob.octo.com/assets/logo-askbob-transparent-4b1499ed7c7574fb292b4df5ca6a921e594e3f88a173a39d47f7db1b5ecd7751.png",
                        "title": "Informations Askbob de " + trigram,
                        "title_link": url,
                        "fields": [
                            {
                                "title": "Email",
                                "value": item.email,
                                "short": false
                            },
                            {
                                "title": "Nom complet",
                                "value": item.first_name + " " + item.last_name,
                                "short": false
                            },
                            {
                                "title": "N° de Téléphone",
                                "value": item.phone_numbers[0],
                                "short": false
                            }
                        ],
                        "image_url": imageUrl,
                        "thumb_url": url
                    }
                ]
            }
            resolve({
                "data": {"slack": slackData},
                "source": "askBob"
            })
        })
    })
}

module.exports = {
    getOcto
}